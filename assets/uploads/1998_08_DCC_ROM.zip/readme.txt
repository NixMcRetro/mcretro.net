Dumped 5th September 2018 from a 27C4100.
Happy 20th birthday Dreamcast Arcade Stick Checker Version 2.00 ROM.
