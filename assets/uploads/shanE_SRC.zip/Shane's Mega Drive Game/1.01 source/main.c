#include <genesis.h>


const u32 tile[8]=
{
        0x00111100,
        0x01144110,
        0x11244211,
        0x11244211,
        0x11222211,
        0x11222211,
        0x01122110,
        0x00111100
};


void myJoyHandler( u16 joy, u16 changed, u16 state)
{
    if (joy == JOY_1)
    {
        if (state & BUTTON_START)
        {
            //player 1 press START button
    VDP_setPaletteColor((PAL0 * 16) + 15, 0x00E0);
    VDP_setTextPalette(PAL0);
    VDP_drawText("Warning! START button activated!", 5, 15);
    VDP_loadTileData( (const u32 *)tile, 0, 1, 0);
   }
        else if (changed & BUTTON_START)
        {
    VDP_drawText("START button has been released...", 5, 16);
            //player 1 released START button
        }
    }
}



int main()
{
    VDP_drawText("McRetro.net", 10, 5);
    VDP_drawText("Blast Processed Since 199X", 5, 6);

    VDP_setPaletteColor((PAL2 * 16) + 15, 0x000E);
    VDP_setTextPalette(PAL2);
    VDP_drawText("Press the START button!", 5, 10);

    JOY_init();
    JOY_setEventHandler( &myJoyHandler );

    while(1)
    {
        //read input
        //move sprite
        //update score
        //draw current screen (logo, start screen, settings, game, gameover, credits...)

        //wait for screen refresh
        VDP_waitVSync();
    }
    return (0);
}

