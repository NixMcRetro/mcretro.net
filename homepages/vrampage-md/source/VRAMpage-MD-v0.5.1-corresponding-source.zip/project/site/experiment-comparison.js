// Read-only comparison helpers for previously exported experiment metadata.
(function(root) {
  'use strict';
  const MAX_BYTES=262144, MAX_DEPTH=16, MAX_NODES=12000;
  function parse(text) {
    if (typeof text!=='string' || new TextEncoder().encode(text).length>MAX_BYTES)
      throw new Error('Experiment export must be at most 256 KB.');
    const data=JSON.parse(text);
    if (!data || typeof data!=='object' || Array.isArray(data)) throw new Error('Expected an experiment JSON object.');
    if (data.schemaVersion!==undefined && (!Number.isInteger(data.schemaVersion)||data.schemaVersion>1||data.schemaVersion<1))
      throw new Error('Unsupported experiment export schema version.');
    const recognizable=(key,value)=>key==='rom'&&!!value&&typeof value==='object'&&!Array.isArray(value)&&
        (Object.hasOwn(value,'name')&&(value.name===null||typeof value.name==='string')||Object.hasOwn(value,'sha256')&&(value.sha256===null||typeof value.sha256==='string'))
      ||key==='vramFault'&&!!value&&typeof value==='object'&&!Array.isArray(value)&&
        typeof value.kind==='string'&&['none','address-stuck-low','address-bridge'].includes(value.kind)
      ||key==='logic'&&!!value&&typeof value==='object'&&!Array.isArray(value)&&
        (value.schemaVersion===1||typeof value.active==='boolean'||value.fault===null||!!value.fault&&typeof value.fault==='object')
      ||key==='logicFault'&&!!value&&typeof value==='object'&&!Array.isArray(value)&&typeof value.kind==='string'
      ||['fmInputFault','psgInputFault','z80RamFault','rgbEncoderFault'].includes(key)&&!!value&&typeof value==='object'&&!Array.isArray(value)&&typeof value.available==='boolean'
      ||key==='corePin'&&typeof value==='string'&&/^[a-f0-9]{40}$/.test(value)
      ||key==='modelVersion'&&typeof value==='string'&&value.length>0;
    if (!Object.keys(data).some(key=>recognizable(key,data[key])))
      throw new Error('JSON does not look like a VRAMpage MD experiment export.');
    let nodes=0;
    function bound(value,depth) {
      if (++nodes>MAX_NODES || depth>MAX_DEPTH) throw new Error('Experiment JSON exceeds supported structure limits.');
      if (!value || typeof value!=='object') return;
      const keys=Object.keys(value);
      if (!Array.isArray(value)&&keys.length>512) throw new Error('Experiment JSON object has too many fields.');
      for (const key of keys) bound(value[key],depth+1);
    }
    bound(data,0);
    return data;
  }
  const path=(object,keys)=>keys.reduce((value,key)=>value&&typeof value==='object'?value[key]:undefined,object);
  const hasPath=(object,keys)=>{
    let parent=object;
    for(const key of keys.slice(0,-1)) {
      if(!parent||typeof parent!=='object'||!Object.hasOwn(parent,key))return false;
      parent=parent[key];
    }
    return !!parent&&typeof parent==='object'&&Object.hasOwn(parent,keys.at(-1));
  };
  const show=value=>{
    if(value===undefined)return 'Unknown';
    if(value===null)return 'None';
    const text=typeof value==='object'?JSON.stringify(value):String(value);
    return text.length>240?`${text.slice(0,237)}…`:text;
  };
  const equal=(a,b)=>{
    if(a===b)return true;
    if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;
    if(Array.isArray(a)||Array.isArray(b))return Array.isArray(a)&&Array.isArray(b)&&a.length===b.length&&a.every((value,index)=>equal(value,b[index]));
    const ak=Object.keys(a).sort(),bk=Object.keys(b).sort();
    return ak.length===bk.length&&ak.every((key,index)=>key===bk[index]&&equal(a[key],b[key]));
  };
  const isInteger=(value,min=0,max=Number.MAX_SAFE_INTEGER)=>Number.isInteger(value)&&value>=min&&value<=max;
  const isPair=value=>value===null||Array.isArray(value)&&value.length===2&&value.every(line=>isInteger(line,0,31));
  const isVramPair=value=>value===null||Array.isArray(value)&&value.length===2&&value.every(line=>isInteger(line,0,7))&&value[0]!==value[1];
  const isLineList=value=>Array.isArray(value)&&value.every(line=>typeof line==='string'&&/^(A(?:[1-9]|1[0-5])|D(?:[0-9]|1[0-5])|\/(?:LWR|UWR))$/.test(line));
  const isRecord=value=>!!value&&typeof value==='object'&&!Array.isArray(value);
  const isCount=value=>typeof value==='string'&&/^\d+$/.test(value)||isInteger(value);
  const isString=value=>typeof value==='string';
  const isBoolean=value=>typeof value==='boolean';
  const isObject=value=>isRecord(value)||Array.isArray(value);
  function identity(a,b,label,keys,valid=()=>true) {
    const av=path(a,keys), bv=path(b,keys);
    const usable=(record,v)=>typeof v==='string'&&v.length>0&&valid(v,record);
    if (!usable(a,av)||!usable(b,bv)) return {label,a:usable(a,av)?show(av):'Unknown',b:usable(b,bv)?show(bv):'Unknown',status:'unknown'};
    return {label,a:show(av),b:show(bv),status:av===bv?'match':'mismatch'};
  }
  function compare(a,b) {
    const ramFault=record=>hasPath(record,['logic','fault'])?path(record,['logic','fault']):record.logicFault;
    const logicAvailability=hasPath(a,['logic'])||hasPath(b,['logic'])?['logic','available']:null;
    const rows=[
      identity(a,b,'ROM SHA-256',['rom','sha256'],v=>/^[a-f0-9]{64}$/.test(v)),
      identity(a,b,'Core Revision',['corePin'],v=>/^[a-f0-9]{40}$/.test(v)),
      identity(a,b,'Build Source Commit',['build','sourceCommit'],(v,record)=>/^[a-f0-9]{40}$/.test(v)&&path(record,['build','status'])==='available'),
      identity(a,b,'Application Version',['build','applicationVersion'],v=>/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(v)),
      identity(a,b,'Model Version',['modelVersion']),
      identity(a,b,'RAM Model Version',['logic','modelVersion']),
      identity(a,b,'RAM Reference Profile',['logic','referenceProfile']),
      identity(a,b,'ROM Title',['rom','name'])
    ];
    const field=(label,keys,availability,valid=()=>true)=> {
      const av=path(a,keys),bv=path(b,keys);
      const aAvailable=!availability||path(a,availability)===true;
      const bAvailable=!availability||path(b,availability)===true;
      if(!aAvailable||!bAvailable) {
        rows.push({label,a:aAvailable?show(av):'Unknown',b:bAvailable?show(bv):'Unknown',status:'unknown'});return;
      }
      if(!hasPath(a,keys)||!hasPath(b,keys)||!valid(av)||!valid(bv)) { rows.push({label,a:valid(av)?show(av):'Unknown',b:valid(bv)?show(bv):'Unknown',status:'unknown'});return; }
      rows.push({label,a:show(av),b:show(bv),status:equal(av,bv)?'match':'mismatch'});
    };
    for (const [key,label,valid] of [
      ['requestedRegion','Requested Region',v=>isInteger(v,0,4)],
      ['activeRequestedRegion','Active Region Request',v=>isInteger(v,0,4)],
      ['regionCode','Effective Region',v=>[0,64,128,192].includes(v)],
      ['pal','PAL Timing',isBoolean],['masterClock','Master Clock',v=>typeof v==='number'&&Number.isFinite(v)&&v>1000000],
      ['frameRate','Frame Rate',v=>typeof v==='number'&&Number.isFinite(v)&&v>=40&&v<=70],
      ['linesPerFrame','Lines Per Frame',v=>v===262||v===313],
      ['width','Video Width',v=>isInteger(v,1,640)],['height','Video Height',v=>isInteger(v,1,480)],
      ['interlaced','Interlaced',isBoolean]]) field(label,['machine',key],['machine','available'],valid);
    const audio=(name,key)=>{
      for(const [label,fieldName] of [['Configured','configured'],['Effective','effective'],['Data Mask','dataMask'],['Bridge A','bridgeA'],['Bridge B','bridgeB']]) {
        const valid=fieldName==='configured'||fieldName==='effective'?isBoolean:
          fieldName==='dataMask'?value=>isInteger(value,0,255):value=>isInteger(value,-1,7);
        field(`${name} ${label}`,[key,fieldName],[key,'available'],valid);
      }
    };
    const ramA=ramFault(a),ramB=ramFault(b);
    for(const [label,get,valid] of [
      ['Kind',v=>v?.kind,value=>typeof value==='string'&&['address','data','address-stuck-low','data-stuck-low','address-mask','line-pair','write-inhibit'].includes(value)],
      ['Access',v=>v?.access,value=>typeof value==='string'&&['read','write','read + write','both'].includes(value)],
      ['Address Mask',v=>v?.addressMask,value=>isInteger(value,0,32767)],
      ['Data Mask',v=>v?.dataMask,value=>isInteger(value,0,65535)],
      ['Write Inhibit Mask',v=>v?.writeInhibitMask,value=>isInteger(value,0,3)],
      ['Lines / Pair',v=>v?.lines??v?.linesPair,value=>isLineList(value)||isPair(value)],
      ['Activation Frame',v=>v?.activationFrame,value=>isInteger(value)]
    ]) {
      const av=ramA===null?null:get(ramA),bv=ramB===null?null:get(ramB);
      const aValid=av===null||valid(av),bValid=bv===null||valid(bv);
      rows.push({label:`RAM Recorded ${label}`,a:aValid?show(av):'Unknown',b:bValid?show(bv):'Unknown',status:av===undefined||bv===undefined||!aValid||!bValid?'unknown':equal(av,bv)?'match':'mismatch'});
    }
    for(const [label,keys,valid] of [
      ['Kind',['vramFault','kind'],value=>typeof value==='string'&&['none','address-stuck-low','address-bridge'].includes(value)],
      ['Address Mask',['vramFault','addressMask'],value=>isInteger(value,0,255)],['Bridge',['vramFault','bridge'],isVramPair],
      ['Model ID',['vramTransaction','modelId'],value=>isInteger(value,1,255)],['Model Version',['vramTransaction','modelVersion'],isString],
      ['Transaction Mask',['vramTransaction','mask'],value=>isInteger(value,0,255)],
      ['Transaction Bridge A',['vramTransaction','bridgeA'],value=>isInteger(value,-1,7)],
      ['Transaction Bridge B',['vramTransaction','bridgeB'],value=>isInteger(value,-1,7)]
    ]) field(`VRAM ${label}`,keys,keys[0]==='vramTransaction'?['vramTransaction','available']:null,valid);
    field('RAM Data Mask',['logic','dataMask'],['logic','dataMaskAvailable'],value=>isInteger(value,0,65535));
    field('RAM Write Inhibit Mask',['logic','writeInhibitMask'],['logic','writeInhibitAvailable'],value=>isInteger(value,0,3));
    audio('FM','fmInputFault'); audio('PSG','psgInputFault');
    for (const [label,key,valid] of [
      ['Configured','configured',isBoolean],['Effective','effective',isBoolean],
      ['Bridge A','bridgeA',value=>isInteger(value,-1,12)],['Bridge B','bridgeB',value=>isInteger(value,-1,12)],
      ['Model Version','modelVersion',isString],['Activation Frame','activationFrame',isInteger],
      ['Recorded Writes','ramWrites',isCount],['Changed Addresses','changedAddresses',isCount],
      ['Z80 Writes','z80Writes',isCount],['68000 Writes','m68kWrites',isCount]
    ]) field(`Z80 RAM ${label}`,['z80RamFault',key],['z80RamFault','available'],valid);
    for (const [label,key,valid] of [
      ['Configured','configured',isBoolean],['Effective','effective',isBoolean],
      ['Cut Mask','cutMask',value=>isInteger(value,0,7)],
      ['Pair','pair',value=>value===null||Array.isArray(value)&&value.length===2&&
        value.every(channel=>isInteger(channel,0,2))&&value[0]!==value[1]],
      ['Model Version','modelVersion',isString],['Reason','reason',isString]
    ]) field(`RGB Encoder ${label}`,['rgbEncoderFault',key],['rgbEncoderFault','available'],valid);
    for(const [name,key] of [['FM','fmInputFault'],['PSG','psgInputFault']]) {
      for(const [label,fieldName] of [['Model Version','modelVersion'],['Changed Writes','changedWrites']])
        field(`${name} ${label}`,[key,fieldName],[key,'available'],fieldName==='changedWrites'?isCount:isString);
    }
    for(const [label,keys,valid] of [
      ['RAM Active',['logic','active'],isBoolean],['RAM Affected Reads',['logic','readCount'],isInteger],['RAM Affected Writes',['logic','writeCount'],isInteger],
      ['Force Resume Enabled',['automaticRecovery','forceResumeEnabled'],isBoolean],
      ['CPU Recovery Enabled',['automaticRecovery','cpuRecoveryEnabled'],isBoolean],
      ['Recovery Wait Frames',['automaticRecovery','waitFrames'],value=>isInteger(value,1,1024)],
      ['Current Frame',['currentFrame'],isInteger],['CPU Flags',['cpuFlags'],value=>isInteger(value,0,65535)],
      ['VRAM Transaction Counts',['vramTransaction','lastFrameCounts'],isRecord],
      ['PSG Recorded Writes',['psgInputFault','inputWrites'],isCount],['FM Recorded Writes',['fmInputFault','inputWrites'],isCount],
      ['Fault Disconnect Outcomes',['faultDisconnects'],isObject],['Checkpoint Events',['checkpointEvents'],isObject],['Checkpoint Segment',['checkpointSegment'],isInteger],['CPU Interventions',['cpuInterventions'],isObject],['Reset State',['resetState'],isString]
    ]) {
      const legacyKeys={
        'logic.active':'faultActive','logic.readCount':'readCount','logic.writeCount':'writeCount'
      };
      const fallback=legacyKeys[keys.join('.')];
      if(fallback) {
        const av=hasPath(a,keys)?path(a,keys):path(a,[fallback]),bv=hasPath(b,keys)?path(b,keys):path(b,[fallback]);
        const availabilityRequired=logicAvailability&&keys[1]!=='active';
        const aValid=valid(av)&&(!availabilityRequired||!hasPath(a,['logic'])||path(a,logicAvailability)===true),bValid=valid(bv)&&(!availabilityRequired||!hasPath(b,['logic'])||path(b,logicAvailability)===true);
        rows.push({label,a:aValid?show(av):'Unknown',b:bValid?show(bv):'Unknown',status:av===undefined||bv===undefined||!aValid||!bValid?'unknown':equal(av,bv)?'match':'mismatch'});
      } else field(label,keys,keys[0]==='psgInputFault'||keys[0]==='fmInputFault'?[keys[0],'available']:
        keys[0]==='vramTransaction'?['vramTransaction','available']:
        ['Current frame','VRAM transaction counts'].includes(label)?logicAvailability:null,valid);
    }
    return rows;
  }
  root.VRAMpageExperimentComparison={parse,compare,MAX_BYTES};
})(typeof window!=='undefined'?window:globalThis);
